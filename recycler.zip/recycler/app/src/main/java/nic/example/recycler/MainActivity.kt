package nic.example.recycler

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import kotlinx.android.synthetic.main.activity_main.*
import nic.example.recycler.data.PlayerListAdapter
import nic.example.recycler.model.Player

class MainActivity : AppCompatActivity() {

    private var adapter: PlayerListAdapter? = null
    private var playerList: ArrayList<Player>? = null
    private var layoutManager: RecyclerView.LayoutManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        playerList = ArrayList<Player>()
        layoutManager = LinearLayoutManager(this)
        adapter = PlayerListAdapter(playerList!!, this)

        recyclerView.layoutManager = layoutManager
        recyclerView.adapter = adapter


        for (i in 0..9){
            val player = Player()
            player.name = "Wyatt" + i
            player.level = 100 + i
            playerList!!.add(player)

        }
        adapter!!.notifyDataSetChanged()
    }
}
