package nic.example.recycler.model

class Player{
    var name: String? = null
    var level: Int? = null

}