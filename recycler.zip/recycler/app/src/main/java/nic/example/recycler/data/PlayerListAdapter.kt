package nic.example.recycler.data

import android.app.Person
import android.content.Context
import android.view.View
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.TextView
import kotlinx.android.synthetic.main.listrow.view.*
import nic.example.recycler.R
import nic.example.recycler.model.Player


class PlayerListAdapter(private val list: ArrayList<Player>,
                        private val context: Context) : RecyclerView.Adapter<PlayerListAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, position: Int): ViewHolder {

        val view = LayoutInflater.from(context).inflate(R.layout.listrow, parent, false)

        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return list.size

    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {

        holder?.bindItem(list[position])

    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bindItem(player: Player){
            var name: TextView = itemView.findViewById(R.id.name) as TextView
            var level: TextView = itemView.findViewById(R.id.level) as TextView

            name.text = player.name
            level.text = player.level.toString()
        }
    }

}